package pl.tt;

import java.util.Scanner;

public class Main {


    private static final double PI = 3.14159265359;

    public static void main(String[] args) {
        double[] data = new double[4];
        double score = 0;
        Scanner scan = new Scanner(System.in);

        System.out.println(

                "welcome to area counter, choose your figures to get their total area " + menu()

        );

        mainloop:
        while(true){

            //mode
            data[0]= scan.nextDouble();

            switch ((int) data[0]){

                case 1 :

                    System.out.println("give a:");
                    data[1]= scan.nextDouble();
                    System.out.println("give b:");
                    data[2]= scan.nextDouble();

                    score += data[1]*data[2];

                    break;

                case 2 :

                    System.out.println("give a:");
                    data[1]= scan.nextDouble();

                    score += data[1]*data[1];

                    break;

                case 3 :

                    System.out.println("give r:");
                    data[1]= scan.nextDouble();

                    score += data[1]*data[1]*3.14;

                    break;

                case 4 :

                    System.out.println("give a:");
                    data[1]= scan.nextDouble();
                    System.out.println("give b:");
                    data[2]= scan.nextDouble();
                    System.out.println("give h:");
                    data[3]= scan.nextDouble();

                    score += ((data[1]+data[2])*data[3])/2;

                    break;

                case 5:

                    System.out.println("give n:");
                    data[1]= scan.nextDouble();
                    System.out.println("give a:");
                    data[2]= scan.nextDouble();

                    double r_big= data[2]/(2*Math.sin(PI/data[1]));
                    double r_small = (data[2]/2)*(1/Math.tan(PI/data[1]));
                    score += data[1]*data[2]*r_small/2;

                    System.out.println("Promień okędu opisanego wynosi " + r_big + "a wpisanego " + r_small);
                    break;


                case 6:

                    System.out.println("give diagonal d1:");
                    data[1]= scan.nextDouble();
                    System.out.println("give diagonal d2:");
                    data[2]= scan.nextDouble();

                    double r;

                    if(data[2]>data[1]){
                        r=data[2]/2;
                    }else{
                        r=data[1]/2;
                    }

                    System.out.println("Promień okręgu opisanego to "+ r + "Możesz w tej figurze wpisać okrąg, ale by poznać jego promień musisz kupić pełną wersję");

                    score += data[1]*data[2]/2;
                    break;
                    case 7:

                    System.out.println("give a:");
                    data[1]= scan.nextDouble();
                    System.out.println("give h:");
                    data[2]= scan.nextDouble();

                    score += data[1]*data[2];
                    break;

                case 8:

                    System.out.println("give a:");
                    data[1]= scan.nextDouble();
                    System.out.println("give h:");
                    data[2]= scan.nextDouble();

                    score += data[1]*data[2]/2;

                    break;


                default: break mainloop;

            }

            System.out.println("Score is: "+ score + menu() );





        }



    }



    private static String menu(){

        return "\n1.Rectangle \n" +
                "2.Square \n" +
                "3.Circle \n" +
                "4.Trapezoid(regular) \n" +
                "5.n-tagon \n" +
                "6.rhombus(diagonals) \n" +
                "7.rhombus(high) \n"   +
                "8.triangle\n" +
                "9. end";

    }

}
