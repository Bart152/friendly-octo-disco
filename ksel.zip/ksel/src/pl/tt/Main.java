package pl.tt;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Give n:");
        int n = input.nextInt();
        int bottom = 1;
        int i;
        int rep = 1;

        for (i = 1 ; i != n ; i++){

            bottom +=2;

        }

        System.out.println(bottom);

        int space = (bottom - 1)/2;
        int fill = 1;



        while(true){



            for(i = space; i != 0; i-- ){

                System.out.print(" ");

            }


            for( i = fill; i != 0; i--){


                    System.out.print("*");


            }

            if (rep == n) break;

            System.out.println();

            space--;
            fill += 2;
            rep++;
        }


    }
}
