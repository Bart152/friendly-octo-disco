package pl.tt;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int[] tab= new int[2];

        Random generator = new
                Random();
        tab[0]=(generator.nextInt(1000000001));






            System.out.println("Try tu guess a number, or insert giveup");

            for (int i = 1; tab[1] != tab[0]; i++) {

                Scanner scan = new Scanner(System.in);
                String x = scan.nextLine();

                if (x.equals("giveup")) {

                    System.out.println("you are a looser, number was " + tab[0] + " and you had " + i + " attempts");
                    break ;

                } else {

                    tab[1] = Integer.parseInt(x);
                }

                if (tab[1] > tab[0]) {
                    System.out.println("Too much");
                } else if (tab[1] < tab[0]) {
                    System.out.println("Not enough");
                } else {
                    System.out.println("Wow you guessed");
                    System.out.println("attempts: " + (i-1));
                    break;

            }
        }
    }
}
