package com.tt.model;

import com.tt.IdProvider;

public class Task {

    private long id;
    private String owner;
    private String name;
    private String description;

    public Task(String owner, String name, String description) {
        this.owner = owner;
        this.name = name;
        this.description = description;
        id = IdProvider.generateId();
    }

    public Task(String owner, String name) {
        this.owner = owner;
        this.name = name;
        this.description = "";
        id = IdProvider.generateId();
    }

    @Override
    public String toString() {
        return
                " id:       " + id + '\n' +
                " osoba:    " + owner + '\n' +
                " nazwa:    " + name + '\n' +
                " opis:     " + description;
    }
}
