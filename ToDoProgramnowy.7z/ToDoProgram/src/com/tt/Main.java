package com.tt;

import com.tt.model.Board;
import com.tt.model.Task;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Board board1 = new Board("DO ZROBIENIA");
        Board board2 = new Board("W TRAKCIE");
        Board board3 = new Board("ZROBIONE");

        System.out.println("podaj imię:");
        String userName = input.nextLine();


        String userInput = "";
        while (!userInput.equals("quit")){

            System.out.println("type command: ");
            userInput = input.nextLine();

            switch(userInput){

                case "quit":
                    break;

                case "add task":

                    System.out.println("podaj nazwę zadania: ");
                    String name = input.nextLine();

                    System.out.println("podaj opis zadania: ");
                    String description = input.nextLine();
                    Task task1 = new Task(userName, name, description);
                    board1.addTask(task1);
                    break;

                case "show to do":
                    board1.printTasks();
                    break;

                case "show in progress":
                    board2.printTasks();
                    break;

                case "show done":
                    board3.printTasks();
                    break;

                case "make in progress":
                    manager.moveTask(board1, board2, task1);

            }





        //Task task1 = new Task(userName, name, description);
        Task task2 = new Task(userName, "sprzatANIE", "posprzataj kuchnie");
        Task task3 = new Task(userName, "Sprzątać", "posprzataj łazienke");


        //board1.addTask(task1);
        //board1.addTask(task2);
        //board1.addTask(task3);

        //System.out.println("Lista zadań z tablicy " + board1.getType());
        //board1.printTasks();
        //System.out.println("Lista zadań z tablicy " + board2.getType());
       // board2.printTasks();

        BoardManager manager = new BoardManager();

        //manager.moveTask(board1, board2, task1);


    }

    }
}
