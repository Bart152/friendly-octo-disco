package com.tt;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        mainloop:
        while (true) {

            System.out.println("    Witaj w liście zadań! Co chcesz zrobić?" + "\n" +
                    "1. Dodać zadanie" + "\n" +
                    "2. Rozpocząć zadanie" + "\n" +
                    "3. Ukończyć zadanie" + "\n" +
                    "4. Usunąć zadanie" + "\n" +
                    "5. Wyjść" + "\n"
            );

            String  option = input.nextLine();

            switch (option) {

                case "1":

                    while (true) {

                        System.out.println("podaj imię:");
                        String userName = input.nextLine();

                        if (userName.equals("koniec")) {

                            break mainloop;

                        }else if(userName.equals("menu")){

                            break;

                        }

                        System.out.println("podaj nazwę zadania: ");
                        String name = input.nextLine();

                        if (name.equals("koniec")) {

                            break mainloop;

                        }else if(name.equals("menu")){

                            break;

                        }

                        System.out.println("podaj opis zadania: ");
                        String description = input.nextLine();

                        if (description.equals("koniec")) {

                            break mainloop;

                        }else if(description.equals("menu")){

                            break;

                        }

                        Task task = new Task(userName, name, description);

                        System.out.println(task.toString());

                        List<Task> toDoTask = new ArrayList<>();
                        System.out.println(toDoTask.size());
                        toDoTask.add(task);
                        System.out.println(toDoTask.size());

                        for (Task task3 : toDoTask) {
                            System.out.println(task3.toString());
                        }

                        //toDoTask.forEach(task1 -> );

                        if (task.askType() == "TO-DO") {

                            System.out.println("zadania do wykonania");

                        }

                        System.out.println("sdfaef:" + task.askType());

                    }

                case "2":

                    System.out.println("Podaj ID zadania:");
                    long id = Long.parseLong(input.nextLine());
                    Task.makeInProgress(id);

                case "5":break mainloop;

            }

        }
    }
}
