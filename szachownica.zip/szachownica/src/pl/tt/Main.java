package pl.tt;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("enter even number");
        int n = input.nextInt();

        boolean[][] a = new boolean[n][n];
         int i = 0;
         int j = 0;

         int x = 1;


         for( int reps = n*n; reps != 0; reps --){

             int y = 1;

             for( int rep = n; rep != 0; rep --){

                if(x%y == 0){

                    a[i][j] = false;

                    break;

                }else{

                    a[i][j] = true;

                }

                y++;

             }

             x++;

         }

        System.out.print(" ");

         for(int top = 1; top != n + 1; top++){




             System.out.print(" ");
             System.out.print(top);

         }

        System.out.println();

         i = 0;
         j = 0;

        for(int top = 1; top != n + 1; top++){

            if(top< 10 ){

                System.out.print(" ");

            }

            System.out.print(top);

            for(int it = n; it != 0; it-- ){

                if(a[i][j]){

                    System.out.print(" ");

                    System.out.print("+");

                }else{

                    System.out.print(" ");

                    System.out.print(".");

                }

            }

            System.out.println();

        }

    }
}
