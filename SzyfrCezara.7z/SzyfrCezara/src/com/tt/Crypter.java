package com.tt;

public class Crypter {

    private static final String[] ALPHABET = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
            "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};



    public static String encode(String message, int step){

        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < message.length(); i++ ){

            sb.append(encodeLetter(message.substring(i, i + 1), step));

        }

        return sb.toString();

    }

    public static String decode(String word, int step){

        return "";

    }

    private static String encodeLetter(String letter, int step){

        return "";

    }

    private static String decodeLetter(String letter, int step){

        return "";

    }

}
