package com.tt;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int step = 5;
        String message  = "Slowo do zaszyfrowania";




        System.out.println(message);
        String encodedMessage = Crypter.decode(message, step);
        System.out.println(encodedMessage);

        String decodedMessage = Crypter.decode(encodedMessage, step);
        System.out.println(decodedMessage);

    }
}
