package com.countaverage;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int i = 0;
        double a = 0;

        System.out.println("Enter your numbers to get average");

        while(true){

            Scanner scan = new Scanner(System.in);
            String number = scan.nextLine();

            if (!number.isEmpty()) a += Double.parseDouble(number);
            else{

                System.out.println(a/i);
                break;

            }

            i++;

        }

    }

}
