package com.tt;

import com.tt.model.Board;
import com.tt.model.Task;

public class BoardManager {

    public void moveTask(Board source, Board target, Task task){

        target.addTask(task);
        source.removeTask(task);

    }

}
