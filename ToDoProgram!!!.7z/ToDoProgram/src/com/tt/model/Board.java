package com.tt.model;

import com.tt.IdProvider;

import java.util.ArrayList;
import java.util.List;

public class Board {

    private Long id;
    private String type;
    private List<Task> tasks;

    public Board(String type) {

        this.type = type;
        this.id = IdProvider.generateId();
        this.tasks = new ArrayList<>();

    }

    public void addTask(Task task) {

        this.tasks.add(task);
        //tasks.sort();

    }

    public void printTasks() {

        for (int i = 0; i < tasks.size(); i++){

            System.out.println(tasks.get(i));

        }

        /*for (Task task: tasks) {

            System.out.println(task);

        }*/

        //tasks.forEach(task -> System.out.println(task));

    }

    public String getType(){
        return type;
    }

    public void removeTask(Task task){
        tasks.remove(task);
    }

}
