package com.tt.model;

import com.tt.IdProvider;

import java.util.Objects;

public class Task {

    private long id;
    private String owner;
    private String name;
    private String description;
    private int priority;

    public Task(String owner, String name, String description, int priority) {
        this.owner = owner;
        this.name = name;
        this.description = description;
        this.priority = priority;
        id = IdProvider.generateId();
    }

    public Task(String owner, String name, int priority) {
        this.owner = owner;
        this.name = name;
        this.description = "";
        this.priority = priority;
        id = IdProvider.generateId();
    }

    @Override
    public String toString() {
        return
                " id:       " + id + '\n' +
                " osoba:    " + owner + '\n' +
                " nazwa:    " + name + '\n' +
                " priorytet:    " + priority + '\n' +
                " opis:     " + description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return priority == task.priority &&
                Objects.equals(owner, task.owner) &&
                Objects.equals(name, task.name) &&
                Objects.equals(description, task.description);
    }

    @Override
    public int hashCode() {

        return Objects.hash(owner, name, description, priority);
    }
}
