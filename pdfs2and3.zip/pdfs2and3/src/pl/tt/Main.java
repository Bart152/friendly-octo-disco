package pl.tt;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.Random;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {


        Scanner input = new Scanner(System.in);
        Random generator = new Random();


        mainLoop:
        while(true) {

            System.out.println(menuMain());

            int mode = input.nextInt();

            switch(mode){

                case 1:

                    firstLoop:
                    while(true){

                        System.out.println(menuFirst());
                        mode = input.nextInt();

                        switch(mode){

                            case 1:

                                System.out.println("Enter a even number");


                                    int number = input.nextInt();

                                    if(number%2==0){

                                        System.out.println("your not even numbers smaller than yours are:");
                                        for(int i=number ; i!=0; i-- ){

                                            if(i%2 != 0) System.out.println(i);

                                            if(i == 1) break;

                                        }

                                    }


                                break ;

                            case 2:

                                System.out.println("enter A(smaller):");
                                int a = input.nextInt();
                                System.out.println("enter B(bigger):");
                                int b = input.nextInt();


                                int scoreFirst = 0;
                                int i = 0;


                                while(true){



                                    scoreFirst += a+i;

                                    if(a+i == b){

                                        System.out.println(scoreFirst);
                                        break ;
                                    }

                                    i++;

                                }

                                do{

                                    if(a+i == b){

                                        System.out.println(scoreFirst);
                                        break ;
                                    }

                                    scoreFirst += a+i;



                                    i++;

                                }while(true);

                                for( ; a+i == b; i++, scoreFirst += a+i){

                                    if(a+i == b){

                                        System.out.println(scoreFirst);
                                        break ;
                                    }

                                }

                                break ;


                            case 3:

                                System.out.println("Enter n:");
                                int n = input.nextInt();

                                for( i = 0; Math.pow(2 , i) < n; i++){

                                    System.out.println(Math.pow(2 , i));

                                }

                                break ;

                            case 4:

                                int sum = 0;
                                i = 1;

                                while (true){

                                    System.out.println("give a, until you enter 0:");
                                    a = input.nextInt();


                                    if(a == 0){

                                        System.out.println("attemts : " + i
                                        + " sum is " + sum);

                                        break ;

                                    }else{

                                        sum += a;

                                    }

                                    i++;

                                }

                                break ;

                            case 5:



                                System.out.println("Enter your numbers to get average");


                                double suma = 0;
                                double[] tab = new double[2];
                                i=0;

                            while(true){


                                    double c = input.nextDouble();

                                    if (c == 0){

                                        System.out.println("average:"+ (suma/i));
                                        System.out.println("sum of min. and max is: " + (tab[0]+ tab[1]));

                                        break;

                                    }
                                    else{

                                        if (c < tab[0]){

                                            tab[0]= c;

                                        }else if( c > tab[1]){

                                            tab[1]=c;

                                        }

                                        suma += c;

                                    }

                                    i++;

                                }

                                break ;

                            case 6:

                                int[] tablica= new int[2];


                                tablica[0]=(generator.nextInt(101));


                                System.out.println("Try tu guess a number, or insert giveup");

                                for( i=1; tablica[1]!=tablica[0];i++) {

                                    Scanner scan = new Scanner(System.in);
                                    String x = scan.nextLine();

                                    if(x.equals("giveup")){

                                        System.out.println("you are a looser, number was "+ tablica[0] +" and you had "+ i + " attempts");
                                        break;

                                    }else {

                                        tablica[1] = Integer.parseInt(x);
                                    }

                                    if (tablica[1]>tablica[0]) {
                                        System.out.println("Too much");
                                    }
                                    else
                                    if (tablica[1]<tablica[0]) {
                                        System.out.println("Not enough");
                                    }
                                    else {
                                        System.out.println("Wow you guessed");
                                        System.out.println("attempts: " + i);
                                        break;
                                    }
                                }

                                break ;

                            case 7:



                                System.out.println("give char");
                                char fill = input.next().charAt(0);

                                System.out.println("give a");
                                a= input.nextInt();

                                System.out.println("give b");
                                b= input.nextInt();

                                System.out.println("give x");
                                int x = input.nextInt();
                                System.out.println("give y");
                                int y = input.nextInt();



                                for(int p = y+1; p != 0; p--){

                                    System.out.println(">");

                                }

                                for(int p = a+1; p != 0; p--){

                                    System.out.println("-");

                                    for(i= x; i != 0; i--) {
                                        System.out.print("-");
                                    }

                                    for (i = b+1; i != 0; i--){

                                        System.out.print(fill);

                                    }

                                    System.out.println("\n");
                                }

                                break ;

                            case 8:

                                break ;

                            case 9:

                                break ;

                            case 10:

                                System.out.println("give your number");
                                a = input.nextInt();

                                for(int h = 1; h != a+1; h++){

                                    if(a%h==0){

                                        System.out.println(h);

                                    }

                                }

                                break ;

                            case 11:

                                System.out.println("give a number");

                                int podzielnik = input.nextInt();
                                for ( i = 1; i < 300; i++) {



                                    boolean liczbaPierwsza = true;

                                    if (i > 3) {

                                        while (podzielnik < i) {
                                            if (i % podzielnik == 0) {

                                                liczbaPierwsza = false;break;

                                            }
                                            podzielnik++;}

                                    }
                                    if (i == podzielnik && liczbaPierwsza) {

                                        System.out.println("TAK " + podzielnik);

                                    }else {

                                        System.out.println("NIE");

                                    }

                                }

                                break ;

                            case 12:

                                break firstLoop;

                        }

                    }

                    break;

                case 2:

                    secondLoop:
                    while(true){

                        System.out.println(menuSecond());
                        mode = input.nextInt();

                        switch(mode){

                            case 1:

                                int[] tab = new int[10];

                                for(int m=0; m!=9 ; m++){

                                    tab[m] = (generator.nextInt(50));

                                }

                                //CONTENT

                                for(int m=0; m!=9 ; m++){

                                    System.out.println(tab[m]);

                                }

                                //MIN
                                int score = tab[0];
                                for (int i=1; i != 9; i++) {
                                    if (score > tab[i]) {
                                        score = tab[i];
                                    }
                                }

                                System.out.println("min. is " + score);

                                //MAX

                                score = tab[0];
                                for (int i=1; i != 9; i++) {
                                    if (score < tab[i]) {
                                        score = tab[i];
                                    }
                                }

                                System.out.println("max. is " + score);

                                //AVG

                                score = 0;

                                for (int i=1; i != 9; i++) {
                                    score += tab[i];
                                }

                                int avg = score/10;

                                System.out.println("avg. is " + avg);

                                //less tha avg
                                score = 0;
                                for (int i=1; i != 9; i++) {
                                    if (tab[i] < avg ) {
                                        score++;
                                    }
                                }

                                System.out.println("smaller than avg: " + score);

                                //more tha avg
                                score = 0;
                                for (int i=1; i != 9; i++) {
                                    if (tab[i] > avg ) {
                                        score++;
                                    }
                                }

                                System.out.println("more than avg: " + score);

                                for(int m=9; m!=0 ; m--){

                                    System.out.println(tab[m]);

                                }


                            case 2:

                            int[] schedule = new int[20];

                                for(int m=0; m!=19 ; m++){

                                    schedule[m] = 1 + (generator.nextInt(10));

                                }

                                System.out.println("random numbers:");

                                for(int i = 0; i != 19; i++){

                                    System.out.print(" " + schedule[i] + " ");

                                }
                                System.out.println();

                                System.out.println("reapited:");
                                System.out.println();

                                for(int i = 0; i != 10; i++){

                                    System.out.print((i+1) + " - ");

                                    score = 0;
                                    for(int j = 0; j != 20; j++ ){

                                        if(schedule[j] == (i+1)){

                                            score++;

                                        }

                                    }

                                    System.out.print(score);
                                    System.out.println();

                                }


                            case 3:



                            case 4:



                            case 5:



                            case 6:



                            case 7:



                            case 8:



                            case 9:



                            case 10:

                                break secondLoop;

                        }

                    }

                case 3:

                    break mainLoop;

            }
        }
    }

    private static String menuMain(){

        return "Choose set of programs:\n" +
                "   1. First PDF loops\n" +
                "   2. Second PDF\n" +
                "   3. Exit";

    }

    private static String menuFirst(){

        return "Choose set of programs:\n" +
                "   1. \n" +
                "   2. \n" +
                "   3. \n" +
                "   4. \n" +
                "   5. \n" +
                "   6. \n" +
                "   7. \n" +
                "   8. \n" +
                "   9. \n" +
                "   10. \n" +
                "   11. \n" +
                "   12. exit";

    }

    private static String menuSecond(){

        return "Choose set of programs:\n" +
                "   1. \n" +
                "   2. \n" +
                "   3. \n" +
                "   4. \n" +
                "   5. \n" +
                "   6. \n" +
                "   7. \n" +
                "   8. \n" +
                "   9. \n" +
                "   10. exit";

    }

}
