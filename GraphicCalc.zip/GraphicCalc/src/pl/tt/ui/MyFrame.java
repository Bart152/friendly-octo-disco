package pl.tt.ui;

import pl.tt.Main;

import javax.swing.*;
import java.awt.*;


public class MyFrame extends JFrame {

    public MyFrame() {

        super("Calc");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 400);
        setVisible(true);

        JPanel row1 = new JPanel();

        JPanel row2 = new JPanel();
        JLabel display = new JLabel(Main.numbers);

        JButton but1 = new JButton("1");
        JButton but2 = new JButton("2");
        JButton but3 = new JButton("3");
        JButton butPlus = new JButton("+");

        JButton but4 = new JButton("4");
        JButton but5 = new JButton("5");
        JButton but6 = new JButton("6");
        JButton butMinus = new JButton("-");

        JButton but7 = new JButton("7");
        JButton but8 = new JButton("8");
        JButton but9 = new JButton("9");
        JButton butDivide = new JButton("/");

        JButton but0 = new JButton("0");
        JButton butDot = new JButton(".");
        JButton butMultiply = new JButton("*");
        JButton butEqual = new JButton("=");

        JButton butMemory = new JButton("MRC");
        JButton butMemoryMinus = new JButton("M-");
        JButton butMemoryPlus = new JButton("M+");
        JButton butClear = new JButton("CE");

        JButton butRoot = new JButton("r");

        GridLayout layout = new GridLayout(2, 1 , 10 , 10);
        setLayout(layout);

        FlowLayout layout1 = new FlowLayout(FlowLayout.RIGHT, 10, 10);
        row1.setLayout(layout1);
        row1.add(display);
        display.setFont (display.getFont ().deriveFont (50.0f));
        add(row1);


        GridLayout layout2 = new GridLayout(6 , 4, 1, 1);
        row2.setLayout(layout2);
        row2.add(but1);

        row2.add(but2);
        row2.add(but3);
        row2.add(butPlus);
        row2.add(but4);
        row2.add(but5);
        row2.add(but6);
        row2.add(butMinus);
        row2.add(but7);
        row2.add(but8);
        row2.add(but9);
        row2.add(butDivide);
        row2.add(but0);
        row2.add(butDot);
        row2.add(butMultiply);
        row2.add(butEqual);
        row2.add(butMemory);
        row2.add(butMemoryMinus);
        row2.add(butMemoryPlus);
        row2.add(butRoot);
        row2.add(butClear);
        add(row2);

    }



}
