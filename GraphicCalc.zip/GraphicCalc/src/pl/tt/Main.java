package pl.tt;

import pl.tt.ui.MyFrame;

public class Main {


    public static String numbers = "12345";

    public static void main(String[] args) {

        new MyFrame().setVisible( true );

    }

}
